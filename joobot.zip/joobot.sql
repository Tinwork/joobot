-- phpMyAdmin SQL Dump
-- version 4.6.5.1
-- https://www.phpmyadmin.net/
--
-- Client :  localhost:3306
-- Généré le :  Ven 28 Avril 2017 à 11:57
-- Version du serveur :  5.6.34
-- Version de PHP :  7.1.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `joobot`
--

-- --------------------------------------------------------

--
-- Structure de la table `bot`
--

CREATE TABLE `bot` (
  `id` int(11) UNSIGNED NOT NULL,
  `id_job` int(11) DEFAULT NULL,
  `id_question` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `bot`
--

INSERT INTO `bot` (`id`, `id_job`, `id_question`) VALUES
(17, 20, '{\"questions\":[\"33\"]}'),
(18, 21, '{\"questions\":[\"33\",\"36\"]}');

-- --------------------------------------------------------

--
-- Structure de la table `candidate`
--

CREATE TABLE `candidate` (
  `id` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `apply_list` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `candidate`
--

INSERT INTO `candidate` (`id`, `firstname`, `lastname`, `email`, `mobile`, `apply_list`) VALUES
(65, 'A', 'A', 'a@a.com', '+336470325566', '{\"profile_20\":{\"question_13\":{\"libelle\":\"hohoho\",\"open\":false,\"response\":\"good\"},\"question_14\":{\"libelle\":\"fgdfg\",\"open\":false,\"response\":\"qsd\"},\"question_22\":{\"libelle\":\"bisoir\",\"open\":false,\"response\":\"array\"}}}');

-- --------------------------------------------------------

--
-- Structure de la table `jobs`
--

CREATE TABLE `jobs` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `subtitle` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `skills` text NOT NULL,
  `date_start` date NOT NULL,
  `date_end` date NOT NULL,
  `candidate` text,
  `thumb` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `jobs`
--

INSERT INTO `jobs` (`id`, `title`, `subtitle`, `description`, `skills`, `date_start`, `date_end`, `candidate`, `thumb`) VALUES
(20, 'Développeur J2EE', 'FOO', 'Un poste de développeur J2EE à pouvoir.', 'Java, JSP, J2EE', '2017-04-25', '2017-05-25', NULL, '/static/assets/img/rabbot/rabbot_dev.png'),
(21, 'Graphiste', 'FOO', 'Un poste de graphiste à pouvoir.', 'Photoshop, Illustator, Paint', '2017-04-25', '2017-05-25', '66, 67', '/static/assets/img/rabbot/rabbot_design.png');

-- --------------------------------------------------------

--
-- Structure de la table `question`
--

CREATE TABLE `question` (
  `id` int(11) NOT NULL,
  `body` text NOT NULL,
  `tips` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `enum` text,
  `open` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Contenu de la table `question`
--

INSERT INTO `question` (`id`, `body`, `tips`, `type`, `enum`, `open`) VALUES
(33, 'Quel est votre couleur préféré ? ', '', 'string', NULL, NULL);

--
-- Index pour les tables exportées
--

--
-- Index pour la table `bot`
--
ALTER TABLE `bot`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `candidate`
--
ALTER TABLE `candidate`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `question`
--
ALTER TABLE `question`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `bot`
--
ALTER TABLE `bot`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT pour la table `candidate`
--
ALTER TABLE `candidate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=68;
--
-- AUTO_INCREMENT pour la table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT pour la table `question`
--
ALTER TABLE `question`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
