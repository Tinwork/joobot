#GFI Candidature n°3243 
## Candidat 
- Firstname : Salut 
- Lastname : Dupont 
- Email : john@gmail.com 
- Mobile : +3365518743 
## Compte Rendu 
>**Quel est vôtre âge ?**<br />&#8594;27 ans

>**Quels sont vos centres d'activités ?**<br />&#8594;Le sport, la musique et la cuisine

